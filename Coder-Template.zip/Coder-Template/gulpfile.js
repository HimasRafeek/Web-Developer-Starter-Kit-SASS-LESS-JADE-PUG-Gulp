/*================================================
	->	Himas Rafeek
	->	https://github.com/HimasRafeek
	->  https://www.facebook.com/mohamed.rima.50
	->  https://www.ihostyou.xyz
==================================================*/
var gulp = require('gulp');
var sass = require('gulp-sass');
var jade = require('gulp-jade');
var less = require('gulp-less');

//Locations of files
var sassloc = 'app/sass/*.scss';
var lessloc = 'less/*.less';
var jadeloc = '*.pug';

//OutPut Locations Of Files
var outsass = 'Dist/css/';
var outless = 'less style';
var outjade = 'jade';

//Watching Commands
var watchSass = 'app/sass/*.scss';
var watchLess = 'less/**/*.less';
var watchJade = '**/*.pug';



gulp.task('sass', function () {
    var scss = gulp.src(sassloc) // Get source files with gulp.src
        .pipe(sass()) // Sends it through a gulp plugin
        .pipe(gulp.dest(outsass)) // Outputs the file in the destination folder
    return scss;
});


gulp.task('less', function () {
    var les = gulp.src(lessloc) // Get source files with gulp.src
        pipe(less({
            pretty: true
        })) // Sends it through a gulp plugin
        .pipe(gulp.dest(outLess)) // Outputs the file in the destination folder
    return les;
});


gulp.task('jade', function () {
    var jad = gulp.src(jadeloc) // Get source files with gulp.src
        .pipe(jade({
            pretty: true
        })) // Sends it through a gulp plugin
        .pipe(gulp.dest(outjade)) // Outputs the file in the destination folder
    return jad;
});




gulp.task('watch', function () {
   gulp.watch(watchSass, ['sass']);
    gulp.watch(watchLess, ['less']);
    gulp.watch(watchJade, ['jade']);
    // Other watchers
});
